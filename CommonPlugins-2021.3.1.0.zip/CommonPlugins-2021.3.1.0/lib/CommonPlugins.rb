include Java
require 'java'

path2 = File.expand_path('..',__FILE__)
path3 = path2 + "/CommonPlugins"
$LOAD_PATH << path3
$CLASSPATH << path3

#puts JRUBY_VERSION
#puts path3

require 'CommonPlugins/simpleaction'


#require "CommonPlugins/Library"

$CLASSPATH << "CommonPlugins" 



module CommonPlugins
  # Your code goes here...
  include_package 'CommonPlugins'

end