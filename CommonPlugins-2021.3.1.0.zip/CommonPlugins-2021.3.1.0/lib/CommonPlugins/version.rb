#module CommonPlugins
module CommonPlugins  	
  	@VERSION = "2021.3.1.0"

  	def self.VERSION
    	return @VERSION
  	end

  	def self.VERSION=(val)
    	@VERSION=val
  	end
end
