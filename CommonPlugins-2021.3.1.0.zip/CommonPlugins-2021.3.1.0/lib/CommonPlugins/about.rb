#Author : Dang Le
#Date :   June 3rd, 2017
#Spreadsheet Compare Plugin
#Create a spreadsheet of stereotypes that are used in
#Comms Profile and G2 Ops plugins
#Keep track of changes and allow user(s) to see changes
#made to stereotype and other properties.
require 'java'
include Java

#import lines
    import java.awt.Insets
    import java.awt.Color
    import javax.swing.JPanel
    import javax.swing.JLabel
    import javax.swing.JComboBox
    import javax.swing.JButton
    import javax.swing.JTextField
    import javax.swing.event.ListSelectionListener
    import java.awt.GridBagLayout
    import java.awt.GridBagConstraints
    import java.awt.event.ActionListener
    import java.awt.Dimension
    import java.awt.FlowLayout
    import javax.swing.JFrame
    import java.awt.Font
    import javax.swing.JCheckBox
    import javax.swing.JOptionPane
    import java.awt.event.WindowEvent
    import java.awt.event.WindowAdapter
    import javax.swing.JFileChooser
    import javax.swing.filechooser.FileNameExtensionFilter
    import javax.swing.ListSelectionModel
    import javax.swing.DefaultListModel
    import javax.swing.JToggleButton
    import javax.swing.JList
    import javax.swing.JScrollPane
    import javax.swing.ScrollPaneConstants
    import javax.swing.ImageIcon
    import java.awt.Dimension
    import java.awt.Image
    import java.awt.Toolkit


#require 'spreadsheet'
#require 'json'
#require 'differ'
#require_relative 'Library'



path2 = File.expand_path('..',__FILE__)
$LOAD_PATH << path2

require 'Library'



module About

    class MainWindow < JFrame
        include Version
        #include G2


        def initialize
            super("About")
            #project = Application.getInstance.getProject
            #create GUI
            initUI
            #@created = false
        end

        def initUI
            panel = JPanel.new

            panel.setBackground Color.new 202, 220, 249
            gridcon = GridBagConstraints.new
            gridbag = GridBagLayout.new
            #panel.setPreferredSize(Dimension.new(481,293))
            panel.setLayout(gridbag)

            #Add title
            title = JLabel.new("G2 Ops Plugin Library")
            title.setFont Font.new "Baskerville", Font::PLAIN, 42
            #img = ImageIcon.new("/Users/DangL/Desktop/img/tata.png")
            #title.setIcon(img)
            gridcon.gridwidth = 10
            gridcon.ipady = 85
            gridcon.ipadx = 85
            gridcon.gridx=1
            gridcon.gridy=0
            gridcon.insets = Insets.new(-90,125,0,40)
            gridcon.anchor= GridBagConstraints::NORTH
            #gridbag.setConstraints(title,gridcon)
            panel.add(title,gridcon)

            versionNum = Version::getVersion

            versionPanel = JLabel.new("Version " + versionNum.to_s)
            #versionPanel = JLabel.new("tata")
            versionPanel.setFont Font.new "Palatino", Font::PLAIN, 14
            #versionPanel.setIcon(img)
            gridcon.gridwidth = 10
            gridcon.ipady = 2
            gridcon.ipadx = 0
            gridcon.gridx=1
            gridcon.gridy=1
            gridcon.insets = Insets.new(-10,30,0,40)
            panel.add(versionPanel,gridcon)

            #Add version  label

            logLabel=JLabel.new("Comms Profile Version :")
            logLabel.setFont Font.new "Palatino", Font::PLAIN, 14
            #logLabel.setFont Font.new "Arial", Font::PLAIN, 11
            logLabel.setLayout(nil)
            logLabel.setPreferredSize(Dimension.new(150,5))
            gridcon.gridx=0
            gridcon.gridy=1

            gridcon.ipady = 3
            gridcon.ipadx = 100
            gridcon.insets = Insets.new(45,570,0,40)
            panel.add(logLabel,gridcon)

            pathLabel=JLabel.new("Version Path :")
            pathLabel.setFont Font.new "Palatino", Font::PLAIN, 14
            #pathLabel.setFont Font.new "Arial", Font::PLAIN, 11
            pathLabel.setLayout(nil)
            pathLabel.setPreferredSize(Dimension.new(150,5))
            gridcon.gridx=0
            gridcon.gridy=1

            gridcon.ipady = 3
            gridcon.ipadx = 100
            gridcon.insets = Insets.new(65,505,0,40)
            panel.add(pathLabel,gridcon)

            #Add log file label
            verLabel=JLabel.new("Log File :")
            verLabel.setFont Font.new "Palatino", Font::PLAIN, 14
            #verLabel.setFont Font.new "Arial", Font::PLAIN, 11
            verLabel.setLayout(nil)
            verLabel.setPreferredSize(Dimension.new(150,5))
            gridcon.gridx=0
            gridcon.gridy=1

            gridcon.ipady = 3
            gridcon.ipadx = 100
            gridcon.insets = Insets.new(85,480,0,40)
            panel.add(verLabel,gridcon)


            #Compare Button
            commsProfileVersionNum = Version::getCommsProfileVersion
            commVersionLabel=JLabel.new(commsProfileVersionNum.to_s)
            commVersionLabel.setFont Font.new "Arial", Font::PLAIN, 14
            commVersionLabel.setLayout(nil)
            commVersionLabel.setPreferredSize(Dimension.new(129,1))
            gridcon.gridx=2
            gridcon.gridy=1
            gridcon.ipady = 3
            gridcon.ipadx = 40
            gridcon.insets = Insets.new(45,190,0,40)
            panel.add(commVersionLabel,gridcon)

            pathLabel2=JLabel.new("Data/Plugin & Versions/Library.rb/Version")
            pathLabel2.setFont Font.new "Arial", Font::PLAIN, 14
            pathLabel2.setLayout(nil)
            pathLabel2.setPreferredSize(Dimension.new(129,1))
            gridcon.gridx=2
            gridcon.gridy=1
            gridcon.ipady = 3
            gridcon.ipadx = 40
            gridcon.insets = Insets.new(65,380,0,40)
            panel.add(pathLabel2,gridcon)

            @button2=JLabel.new("{MagicDraw path}/plugins")
            @button2.setFont Font.new "Arial", Font::PLAIN, 14
            @button2.setLayout(nil)
            @button2.setPreferredSize(Dimension.new(129,1))
            gridcon.gridx=2
            gridcon.gridy=1
            gridcon.ipady = 3
            gridcon.ipadx = 40
            gridcon.insets = Insets.new(85,280,0,40)
            panel.add(@button2,gridcon)
            #Add action listener for state changes
            #Add action listener for state changes
            #logLabel.addActionListener{|evt| generateWorksheet}

            #Add action listener for state changes
            #logLabel2.addActionListener{|evt| compareWorksheet}

            #JFrame attributes
            c = JFrame.new

            #JFrame attributes
            c.getContentPane.add panel
            #c.setPreferredSize(Dimension.new(481,293))
            c.setResizable(true)
            c.setSize 700, 430
            c.setLocationRelativeTo nil
            c.setVisible true
            c.setDefaultCloseOperation(javax.swing.WindowConstants::DISPOSE_ON_CLOSE)

        end

    end  #end class


#MainWindow.new

end  #end module
