java_import com.nomagic.magicdraw.actions.MDAction
java_import com.nomagic.magicdraw.ui.browser.actions.DefaultBrowserAction;
java_import com.nomagic.magicdraw.ui.dialogs.MDDialogParentProvider;
java_import com.nomagic.magicdraw.ui.actions.DefaultDiagramAction;

require 'java'
include Java

path2 = File.expand_path('..',__FILE__)
$LOAD_PATH << path2

require 'about'
require 'CassandraExport'
require 'circuitidentifier'
require 'circuitmap'
require 'compare'
#require 'cvn55'
require 'diagram_change'
require 'ia_services'
require 'import'
require 'import3'
require 'importR'
require 'messageflow'
require 'MessageRepairer'
require 'networkdiagrambuilder'
require 'op_analysis'
require 'power_analysis'
require 'ppsimport'
require 'programowner'
require 'subsystemRollup'
require 'swap'
#require 'swftsImport'
require 'swftsImportBMCM'
require 'version'
require 'VersionManagement'
require 'interfaceIdentifier'
require 'swftsDelta'
require 'requirementsMap'
require 'ucRoadMapExport'
require 'modelExport'
require 'cpgGenerator'
require 'migration'
require 'propRedefine'
require 'swhwImport'
require 'stereotypesExtraction'
require 'gsmValidation'
require 'gsmExport'
require 'tasModelExport'


module Action

  class AboutAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        About::MainWindow.new
      end
    end

  class CompareAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
    end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        Compare::MainWindow.new

    end
  end

  class SingleMessageAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
    end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        SingleMessage::MainWindow.new

    end
  end

  class MultiMessageAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
    end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        MultiMessage::MainWindow.new

    end
  end

    class ImportAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        Import::MainWindow.new

      end
    end

    class ImportNameAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        ImportName::MainWindow.new

      end
    end

    class MessageMapAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        MessageMap::MainWindow.new

      end
    end

    class MissionThreadAction < MDAction
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        MissionThread::MainWindow.new

      end
    end

    
  class MessageFlowAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        MessageFlow::MainWindow.new
      end
  end

  class CircuitIdentifierAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        CircuitIdentifier::MainWindow.new
      end
  end

    class ProgramOwnerIDAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        ProgramOwnerID::MainWindow.new
      end
    end

    class SWAPAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        SWAPswing::MainWindow.new
      end
    end

    class CircuitMapAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        CircuitMap::MainWindow.new
      end
    end

    
    class ExportAction < MDAction
  
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        Exporter3::MainWindow.new
      end
    end

    class IAServiceAction < MDAction
      
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        IAServices::MainWindow.new
      end
    end

    class PowerAction < MDAction
      
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        Power::MainWindow.new
      end
    end

    class OpticalAction < MDAction
      
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        Optical::MainWindow.new
      end
    end

    class SpreadsheetCompareAction < MDAction
      # constructor
      def initialize(id, name)
        # pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action peformed when submenu category selected
        SpreadsheetCompare::MainWindow.new
      end
    end



    class MessageRepairAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        MessageRepair::MainWindow.new
      end
    end
    

    class NetworkDiagramBuilderAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        NetworkDiagramBuilder::MainWindow.new
      end
    end

    class SWFTSImportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        SWFTSImport::MainWindow.new
      end
    end
=begin
    class RelationshipImportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        RelationshipImport::MainWindow.new
      end
    end
=end
    class RelationshipImportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        SecretRelationshipImport::MainWindow.new
      end
    end

    class SubsystemRollUpAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        SubsystemRollUp::MainWindow.new
      end
    end

    class CVNSystemInterfaceAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        CVNSystemInterface::MainWindow.new
      end
    end

    class NessusAnalysisAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        NessusAnalysis::MainWindow.new
      end
    end

    class RequirementsMapAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        RequirementsMap::MainWindow.new
      end
    end
    
    #UCRModelExport
    class UCRModelExportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        UCRModelExport::MainWindow.new
      end
    end

    #ModelExport
    class ModelExportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        ModelExport::MainWindow.new
      end
    end
    #CPGgenerator
    class CPGgeneratorAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        CPGgenerator::MainWindow.new
      end
    end

    #ProjectMigration
    class ProjectMigrationAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        ProjectMigration::MainWindow.new
      end
    end

    #property redefine
    class PropertyRedefineAction < DefaultBrowserAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        PropertyRedefine::TreeBrowserClass.new
      end
    end

    class PropertyRedefineDiagramAction < DefaultDiagramAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        PropertyRedefine::DiagramActionClass.new
      end
    end

    
    class PPSImportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        PPSImport::MainWindow.new
      end
    end
    #2020 SW-HW Import
    class SWHWImportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        SWHWImport::MainWindow.new
      end
    end
    #StereotypeExtraction plugin
    class StereotypeExtractionAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        StereotypeExtraction::MainWindow.new
      end
    end
    #GSM Validation plugin
    class GSMValidationAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        GSMValidation::MainWindow.new
      end
    end
    #GSM Export plugin
    class GSMExportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        GSMExport::MainWindow.new
      end
    end
    #TAS Export plugin
    class TasExportAction < MDAction
      #constructor
      def initialize(id, name)
        #pass values to MDAction (Parent Class)
        super(id,name,nil,nil)
      end

      def actionPerformed(e)
        # Action performed when submenu category selected
        TasExport::MainWindow.new
      end
    end

 end